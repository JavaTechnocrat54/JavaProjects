package com.shopme.service.impl;

public interface IOrderService {

}
