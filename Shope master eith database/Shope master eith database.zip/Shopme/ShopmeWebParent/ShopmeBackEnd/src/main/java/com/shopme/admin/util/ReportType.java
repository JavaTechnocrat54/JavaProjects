package com.shopme.admin.util;

public enum ReportType {
	DAY, MONTH, CATEGORY, PRODUCT
}
