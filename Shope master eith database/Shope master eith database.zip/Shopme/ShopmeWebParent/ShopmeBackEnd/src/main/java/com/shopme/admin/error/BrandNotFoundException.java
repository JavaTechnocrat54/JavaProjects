package com.shopme.admin.error;

public class BrandNotFoundException extends Exception {

	public BrandNotFoundException(String message) {
		super(message);
	}
}
