package com.shopme.admin.util;

public enum MenuMoveDirection {
	UP, DOWN
}
