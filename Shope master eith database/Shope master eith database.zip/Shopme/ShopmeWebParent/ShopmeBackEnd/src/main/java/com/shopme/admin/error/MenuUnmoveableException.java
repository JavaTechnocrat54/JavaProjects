package com.shopme.admin.error;

public class MenuUnmoveableException extends Exception {

	public MenuUnmoveableException(String message) {
		super(message);
	}

}
