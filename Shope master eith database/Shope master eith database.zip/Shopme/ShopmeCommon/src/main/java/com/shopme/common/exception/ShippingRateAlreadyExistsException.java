package com.shopme.common.exception;

public class ShippingRateAlreadyExistsException extends Exception {

	public ShippingRateAlreadyExistsException(String message) {
		super(message);
	}

}
