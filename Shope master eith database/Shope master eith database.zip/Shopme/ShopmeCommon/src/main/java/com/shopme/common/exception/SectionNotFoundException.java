package com.shopme.common.exception;

public class SectionNotFoundException extends Exception {

	public SectionNotFoundException(String message) {
		super(message);
	}

}
