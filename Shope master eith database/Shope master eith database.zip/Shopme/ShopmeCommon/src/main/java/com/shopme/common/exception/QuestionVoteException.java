package com.shopme.common.exception;

public class QuestionVoteException extends Exception {

	public QuestionVoteException(String message) {
		super(message);
	}

}
