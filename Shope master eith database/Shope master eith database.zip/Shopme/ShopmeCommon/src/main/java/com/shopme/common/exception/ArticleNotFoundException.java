package com.shopme.common.exception;

public class ArticleNotFoundException extends Exception {

	public ArticleNotFoundException(String message) {
		super(message);
	}

}
