package com.shopme.common.exception;

public class MenuItemNotFoundException extends Exception {

	public MenuItemNotFoundException(String message) {
		super(message);
	}

}
