package com.shopme.common.exception;

public class PayPalApiException extends Exception {

	public PayPalApiException(String message) {
		super(message);
	}

}
